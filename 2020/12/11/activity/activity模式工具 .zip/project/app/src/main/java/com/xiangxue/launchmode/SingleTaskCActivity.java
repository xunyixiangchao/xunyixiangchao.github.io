package com.xiangxue.launchmode;

public class SingleTaskCActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "SingleTaskCActivity";
    }
}
