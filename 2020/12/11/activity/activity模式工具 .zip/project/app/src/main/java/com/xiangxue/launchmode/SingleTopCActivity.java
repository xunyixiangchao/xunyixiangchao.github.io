package com.xiangxue.launchmode;

public class SingleTopCActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "SingleTopCActivity";
    }
}
