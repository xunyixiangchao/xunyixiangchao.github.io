package com.xiangxue.launchmode;

public class StandardBActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "StandardBActivity";
    }
}
