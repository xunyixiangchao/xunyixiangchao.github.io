package com.xiangxue.launchmode;

public class StandardAActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "StandardAActivity";
    }
}
