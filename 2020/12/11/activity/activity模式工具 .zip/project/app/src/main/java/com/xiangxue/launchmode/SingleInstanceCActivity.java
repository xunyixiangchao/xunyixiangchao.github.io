package com.xiangxue.launchmode;

public class SingleInstanceCActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "SingleInstanceCActivity";
    }
}
