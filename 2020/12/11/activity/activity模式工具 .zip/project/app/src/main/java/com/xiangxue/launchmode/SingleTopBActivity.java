package com.xiangxue.launchmode;

public class SingleTopBActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "SingleTopBActivity";
    }
}
