package com.xiangxue.launchmode;

public class SingleInstanceAActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "SingleInstanceAActivity";
    }
}
