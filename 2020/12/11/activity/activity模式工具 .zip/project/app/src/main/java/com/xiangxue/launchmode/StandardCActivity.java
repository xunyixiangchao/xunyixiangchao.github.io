package com.xiangxue.launchmode;

public class StandardCActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "StandardCActivity";
    }
}
