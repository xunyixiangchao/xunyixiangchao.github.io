package com.xiangxue.launchmode;

public class SingleTaskBActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "SingleTaskBActivity";
    }
}
