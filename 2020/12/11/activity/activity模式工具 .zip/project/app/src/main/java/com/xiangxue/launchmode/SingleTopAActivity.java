package com.xiangxue.launchmode;

public class SingleTopAActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "SingleTopAActivity";
    }
}
