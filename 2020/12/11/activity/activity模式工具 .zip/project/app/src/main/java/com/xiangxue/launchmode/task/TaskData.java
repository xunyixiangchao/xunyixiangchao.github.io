package com.xiangxue.launchmode.task;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;

import com.xiangxue.launchmode.BaseActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TaskData {

    private static TaskData sInstance;
    private int taskId;
    private String activityName;


    /**
     * key -> Task id, value -> History
     */
    private Map<Integer, List<TaskData>> mData = new HashMap<>();

    private TaskData() {
    }

    private TaskData(int taskId, String activityName) {
        this.taskId = taskId;
        this.activityName = activityName;
    }

    public static TaskData getInstance() {
        if (sInstance == null) {
            sInstance = new TaskData();
        }

        return sInstance;
    }

    // Function
    public void add(BaseActivity activity) {
        int taskId = getCurrentTaskId(activity);
        int histId = activity.getId();
        List<TaskData> histIdList = mData.get(taskId);
        if (histIdList == null) {
            histIdList = new ArrayList<>();
        }
        histIdList.add(new TaskData(histId, activity.getClass().getSimpleName()));
        mData.put(taskId, histIdList);
    }

    public void remove(BaseActivity activity) {
        int id = activity.getId();

        for (Map.Entry<Integer, List<TaskData>> kv : mData.entrySet()) {
            int taskId = kv.getKey();
            List<TaskData> histIdList = kv.getValue();
            histIdList.remove(Integer.valueOf(id));
            mData.put(taskId, histIdList);
        }
    }

    public Map<Integer, List<TaskData>> getData() {
        return mData;
    }

    // Internal
    private int getCurrentTaskId(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Activity.ACTIVITY_SERVICE);
        List<ActivityManager.AppTask> appTaskList = activityManager.getAppTasks();
        ActivityManager.RecentTaskInfo taskInfo = appTaskList.get(0).getTaskInfo();

        return taskInfo.persistentId;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }
}
