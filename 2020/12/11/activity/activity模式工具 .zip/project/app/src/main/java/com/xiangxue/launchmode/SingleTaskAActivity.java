package com.xiangxue.launchmode;

public class SingleTaskAActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "SingleTaskAActivity";
    }
}
