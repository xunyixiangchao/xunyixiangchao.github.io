package com.xiangxue.launchmode;

public class SingleInstanceBActivity extends BaseActivity {

    @Override
    protected String getTAG(){
        return "SingleInstanceBActivity";
    }
}
